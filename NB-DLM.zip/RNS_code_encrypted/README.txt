# NBDLM

Source code accompanying the paper "Seizure count forecasting to aid diagnostic testing in epilepsy" by Wang et al.
NBDLM is a dynamic linear model which can be used to fit and forecast seizure generating processes. 
This folder contains code to replicate the simulation studies. Please see below for instructions on how to run the simulations.

## Instructions for decrypting source files

To request the decryption password, please complete the request form at https://forms.gle/BuyQstRkDs56VCrk9.
Install the R package `encryptr`. 
Run the code in `source_file_decryption.R` to decrypt all source files.
When prompted, enter the decryption password. 

## Instructions

The R packages required for running each simulation are listed at the top of the files.
Below are descriptions of the files.

1. NBDLM_training.R -- source file for training the model
2. NBDLM_filter_forecast.R -- source file for running the particle filter and forecasting algorithm
3. simulation_code.R -- code to run the simulation studies

### Authors  

Emily T. Wang, Sharon Chiang, Stephen Cleboski, Vikram R. Rao, Marina Vannucci, and Zulfi Haneef