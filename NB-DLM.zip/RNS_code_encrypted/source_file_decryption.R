library(encryptr)

# First, request the decryption password by following instructions in the README.
# Then execute the below code, entering password when prompted.

decrypt_file('NBDLM_training.R.encryptr.bin', 'NBDLM_training.R')
decrypt_file('NBDLM_filter_forecast.R.encryptr.bin', 'NBDLM_filter_forecast.R')
decrypt_file('simulation_code.R.encryptr.bin', 'simulation_code.R')